﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    //public class UrlAttribute : RegularExpressionAttribute
    //{
    //    public UrlAttribute()
    //        : base(@"^(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?") { }

    //    public override bool IsValid(object value) {
    //        if (value == null || value.ToString().IsNullOrEmpty())
    //            return false;
    //        return base.IsValid(value);
    //    }
    //}
}